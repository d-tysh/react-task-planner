import styled from "@emotion/styled";

export const AppContainer = styled.div`
    padding: 12px;
    max-width: 600px;
    margin: 0 auto;
`;