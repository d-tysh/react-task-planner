import styled from "@emotion/styled";

export const ListItemWrapper = styled.div`
    display: flex;
    justify-content: space-between;
`;