import styled from "@emotion/styled";

export const ButtonWrapper = styled.div`
    display: flex;
    gap: 8px;
    align-items: center;
`;