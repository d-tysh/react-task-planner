export const statusFilters = Object.freeze({
    all: 'all',
    active: 'active',
    completed: 'completed'
})