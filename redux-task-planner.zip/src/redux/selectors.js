export const getTasks = state => state.tasks;

export const getFilter = state => state.filters.status;